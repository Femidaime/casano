<?php if ( ! defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.

$data_meta = new Casano_ThemeOption();
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// META BOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options = array();
// -----------------------------------------
// Page Meta box Options                   -
// -----------------------------------------
$options[] = array(
	'id'        => '_custom_metabox_theme_options',
	'title'     => esc_html__( 'Custom Options', 'casano-toolkit' ),
	'post_type' => 'page',
	'context'   => 'normal',
	'priority'  => 'high',
	'sections'  => array(
		array(
			'name'   => 'header_footer_theme_options', // !??
			'title'  => esc_html__( 'Header Settings', 'casano-toolkit' ),
			'icon'   => 'fa fa-cube',
			'fields' => array(
				array(
					'type'    => 'subheading',
					'content' => esc_html__( 'Header Settings', 'casano-toolkit' ),
				),
				array(
					'id'      => 'enable_custom_header',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable Custom Header', 'casano-toolkit' ),
					'default' => false,
					'desc'    => esc_html__( 'The default is off. If you want to use separate custom page header, turn it on.', 'casano-toolkit' ),
				),
				array(
					'id'         => 'enable_sticky_menu',
					'type'       => 'select',
					'title'      => esc_html__( 'Sticky Header', 'casano-toolkit' ),
					'options'    => array(
						'none'  => esc_html__( 'Disable', 'casano-toolkit' ),
						'smart' => esc_html__( 'Sticky Header', 'casano-toolkit' ),
					),
					'default'    => 'none',
					'dependency' => array( 'enable_custom_header', '==', true ),
				),
				array(
					'id'         => 'metabox_casano_logo',
					'type'       => 'image',
					'title'      => esc_html__( 'Custom Logo', 'casano-toolkit' ),
					'dependency' => array( 'enable_custom_header', '==', true ),
				),
				array(
					'id'         => 'casano_metabox_used_header',
					'type'       => 'select_preview',
					'title'      => esc_html__( 'Header Layout', 'casano-toolkit' ),
					'desc'       => esc_html__( 'Select a header layout', 'casano-toolkit' ),
					'options'    => $data_meta->header_options,
					'default'    => 'style-01',
					'dependency' => array( 'enable_custom_header', '==', true ),
				),
				array(
					'id'         => 'header_position',
					'type'       => 'select',
					'title'      => esc_html__( 'Header Type', 'casano-toolkit' ),
					'options'    => array(
						'relative' => esc_html__( 'Header No Transparent', 'casano-toolkit' ),
						'absolute' => esc_html__( 'Header Transparent', 'casano-toolkit' ),
					),
					'default'    => 'relative',
					'dependency' => array( 'enable_custom_header|casano_metabox_used_header', '==|!=', 'true|sidebar' ),
				),
                array(
                    'id'         => 'header_color',
                    'type'       => 'select',
                    'title'      => esc_html__( 'Header Color', 'casano-toolkit' ),
                    'options'    => array(
                        'dark' => esc_html__( 'Header Text Dark', 'casano-toolkit' ),
                        'light' => esc_html__( 'Header Text Light', 'casano-toolkit' ),
                    ),
                    'default'    => 'dark',
                    'dependency' => array( 'enable_custom_header|casano_metabox_used_header', '==|!=', 'true|sidebar' ),
                ),
			)
		),
		array(
			'name'   => 'page_banner_settings',
			'title'  => esc_html__( 'Page Banner Settings', 'casano-toolkit' ),
			'icon'   => 'fa fa-cube',
			'fields' => array(
				array(
					'id'      => 'enable_custom_banner',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable Page Custom Banner', 'casano-toolkit' ),
					'default' => false,
					'desc'    => esc_html__( 'The default is off. If you want to use separate custom page banner, turn it on.', 'casano-toolkit' ),
				),
				array(
					'id'         => 'hero_section_type',
					'type'       => 'select',
					'title'      => esc_html__( 'Banner Type', 'casano-toolkit' ),
					'options'    => array(
						'disable'        => esc_html__( 'Disable', 'casano-toolkit' ),
						'has_background' => esc_html__( 'Has Background', 'casano-toolkit' ),
						'no_background'  => esc_html__( 'No Background ', 'casano-toolkit' ),
						'rev_background' => esc_html__( 'Revolution', 'casano-toolkit' ),
					),
					'default'    => 'no_background',
					'dependency' => array( 'enable_custom_banner', '==', true ),
				),
				array(
					'id'         => 'bg_banner_page',
					'type'       => 'image',
					'title'      => esc_html__( 'Background Banner', 'casano-toolkit' ),
					'dependency' => array( 'enable_custom_banner|hero_section_type', '==|==', 'true|has_background' ),
				),
				array(
					'id'         => 'casano_metabox_header_rev_slide',
					'type'       => 'select',
					'options'    => casano_rev_slide_options(),
					'title'      => esc_html__( 'Revolution', 'casano-toolkit' ),
					'dependency' => array( 'enable_custom_banner|hero_section_type', '==|==', 'true|rev_background' ),
				),
				array(
					'id'         => 'page_banner_full_width',
					'type'       => 'switcher',
					'title'      => esc_html__( 'Banner Background Full Width', 'casano-toolkit' ),
					'default'    => 1,
					'dependency' => array( 'enable_custom_banner|hero_section_type', '==|==', 'true|has_background' ),
				),
				array(
					'id'         => 'page_banner_breadcrumb',
					'type'       => 'switcher',
					'title'      => esc_html__( 'Enable Breadcrumb', 'casano-toolkit' ),
					'default'    => 0,
					'dependency' => array(
						'enable_custom_banner|hero_section_type',
						'==|any',
						'true|no_background,has_background'
					),
					'desc'       => esc_html__( 'This option has no effect on front page and blog page', 'casano-toolkit' )
				),
				array(
					'id'         => 'page_height_banner',
					'type'       => 'number',
					'title'      => esc_html__( 'Banner Height', 'casano-toolkit' ),
					'default'    => 420,
					'dependency' => array(
						'enable_custom_banner|hero_section_type',
						'==|any',
						'true|no_background,has_background'
					),
				),
				array(
					'id'         => 'show_hero_section_on_header_mobile',
					'type'       => 'switcher',
					'title'      => esc_html__( 'Show Header Banner On Mobile', 'casano-toolkit' ),
					'default'    => false,
					'desc'       => esc_html__( 'If enabled, the "Header Banner" is still displayed on the mobile. This option only works when the mobile header is enabled in Theme Options', 'casano-toolkit' ),
					'dependency' => array( 'enable_custom_banner', '==', 'true' ),
				),
			),
		),
        array(
            'name'   => 'boxed_body_settings',
            'title'  => esc_html__( 'Boxed Body Settings', 'casano-toolkit' ),
            'icon'   => 'fa fa-cube',
            'fields' => array(
                array(
                    'id'      => 'enable_boxed_body',
                    'type'    => 'switcher',
                    'title'   => esc_html__( 'Enable Boxed Body', 'casano-toolkit' ),
                    'default' => false,
                    'desc'    => esc_html__( 'The default is off. If you want to use separate boxed body, turn it on.', 'casano-toolkit' ),
                ),
                array(
                    'id'         => 'bg_body',
                    'type'       => 'image',
                    'title'      => esc_html__( 'Background body', 'casano-toolkit' ),
                    'default'    => '',
                    'dependency' => array( 'enable_boxed_body', '==', 'true' ),
                ),
            ),
        ),
		array(
			'name'   => 'footer_settings',
			'title'  => esc_html__( 'Footer Settings', 'casano-toolkit' ),
			'icon'   => 'fa fa-cube',
			'fields' => array(
				array(
					'id'      => 'enable_custom_footer',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable Custom Footer', 'casano-toolkit' ),
					'default' => false,
				),
				array(
					'id'      => 'disable_footer',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Disable Footer', 'casano-toolkit' ),
					'default' => false,
					'dependency' => array( 'enable_custom_footer', '==', true ),
				),
				array(
					'id'         => 'casano_metabox_footer_options',
					'type'       => 'select',
					'title'      => esc_html__( 'Select Footer Builder', 'casano-toolkit' ),
					'options'    => 'posts',
					'query_args' => array(
						'post_type'      => 'footer',
						'orderby'        => 'post_date',
						'order'          => 'ASC',
						'posts_per_page' => - 1
					),
					'dependency' => array( 'enable_custom_footer', '==', true ),
				),
			)
		),
	),
);

// -----------------------------------------
// Product Meta box Options
// -----------------------------------------
$global_product_style      = casano_toolkit_get_option( 'casano_woo_single_product_layout', 'default' );
$all_product_styles        = array(
	'default'           => esc_html__( 'Default', 'casano-toolkit' ),
	'vertical_thumnail' => esc_html__( 'Thumbnail Vertical', 'casano-toolkit' ),
	'sticky_detail'     => esc_html__( 'Sticky Detail', 'casano-toolkit' ),
	'gallery_detail'    => esc_html__( 'Gallery Detail', 'casano-toolkit' ),
    'with_background'   => esc_html__( 'With Background', 'casano-toolkit' ),
    'slider_large'      => esc_html__( 'Slider large', 'casano-toolkit' ),
	'center_slider'     => esc_html__( 'Center Slider', 'casano-toolkit' ),
);
$global_product_style_text = isset( $all_product_styles[ $global_product_style ] ) ? $all_product_styles[ $global_product_style ] : $global_product_style;
$options[]                 = array(
	'id'        => '_custom_product_metabox_theme_options',
	'title'     => esc_html__( 'Custom Options', 'casano-toolkit' ),
	'post_type' => 'product',
	'context'   => 'normal',
	'priority'  => 'high',
	'sections'  => array(
		array(
			'name'   => 'product_options',
			'title'  => esc_html__( 'Product Configure', 'casano-toolkit' ),
			'icon'   => 'fa fa-cube',
			'fields' => array(
				array(
					'id'         => 'size_guide',
					'type'       => 'switcher',
					'title'      => esc_html__( 'Size guide', 'casano-toolkit' ),
					'desc'       => esc_html__( 'On or Off Size guide', 'casano-toolkit' ),
					'default'    => false,
				),
				array(
					'id'         => 'casano_sizeguide_options',
					'type'       => 'select',
					'title'      => esc_html__( 'Select Size Guide Builder', 'casano-toolkit' ),
					'options'    => 'posts',
					'dependency' => array( 'size_guide', '==', true ),
					'query_args' => array(
						'post_type'      => 'sizeguide',
						'orderby'        => 'post_date',
						'order'          => 'ASC',
						'posts_per_page' => - 1
					),
				),
				array(
					'id'      => 'product_style',
					'type'    => 'select',
					'title'   => esc_html__( 'Choose Style', 'casano-toolkit' ),
					'desc'    => esc_html__( 'Choose Product Style', 'casano-toolkit' ),
					'options' => array(
						'global'            => sprintf( esc_html__( 'Use Theme Options Style: %s', 'casano-toolkit' ), $global_product_style_text ),
						'default'           => esc_html__( 'Default', 'casano-toolkit' ),
						'vertical_thumnail' => esc_html__( 'Thumbnail Vertical', 'casano-toolkit' ),
						'sticky_detail'     => esc_html__( 'Sticky Detail', 'casano-toolkit' ),
						'gallery_detail'    => esc_html__( 'Gallery Detail', 'casano-toolkit' ),
						'with_background'   => esc_html__( 'With Background', 'casano-toolkit' ),
                        'slider_large'      => esc_html__( 'Slider large', 'casano-toolkit' ),
                        'center_slider'     => esc_html__( 'Center Slider', 'casano-toolkit' ),
					),
					'default' => 'global',
				),
				array(
					'id'         => 'product_img_bg_color',
					'type'       => 'color_picker',
					'title'      => esc_html__( 'Image Background Color', 'casano-toolkit' ),
					'default'    => 'rgba(0,0,0,0)',
					'rgba'       => true,
					'dependency' => array(
						'product_style',
						'==',
						'with_background'
					),
					'desc'       => esc_html__( 'For "Big Images" style only. Default: transparent', 'casano-toolkit' ),
				),
			)
		),
	)
);
$options[]                 = array(
	'id'        => '_offer_boxed_product_metabox_theme_options',
	'title'     => esc_html__( 'Offer Boxed', 'casano-toolkit' ),
	'post_type' => 'product',
	'context'   => 'normal',
	'priority'  => 'high',
	'sections'  => array(
		array(
			'name'   => 'offer_boxed_product_options',
			'title'  => esc_html__( 'Offer Boxed Configure', 'casano-toolkit' ),
			'icon'   => 'fa fa-cube',
			'fields' => array(
				array(
					'id'      => 'title_offer_boxed',
					'type'    => 'text',
					'title'   => esc_html__( 'Offer Boxed Title', 'casano-toolkit' ),
					'default' => '',
				),
				array(
					'id'      => 'list_offer_boxed',
					'type'    => 'wysiwyg',
					'title'   => esc_html__( 'List Boxed Content', 'casano-toolkit' ),
					'default' => '',
				),
			)
		),
	)
);
// -----------------------------------------
// Page Footer Meta box Options            -
// -----------------------------------------
$options[] = array(
	'id'        => '_custom_footer_options',
	'title'     => esc_html__( 'Custom Footer Options', 'casano-toolkit' ),
	'post_type' => 'footer',
	'context'   => 'normal',
	'priority'  => 'high',
	'sections'  => array(
		array(
			'name'   => esc_html__( 'FOOTER STYLE', 'casano-toolkit' ),
			'fields' => array(
				array(
					'id'       => 'casano_footer_style',
					'type'     => 'select',
					'title'    => esc_html__( 'Footer Style', 'casano-toolkit' ),
					'subtitle' => esc_html__( 'Select a Footer Style', 'casano-toolkit' ),
					'options'  => $data_meta->footer_options,
					'default'  => 'default',
				),
			),
		),
	),
);
// -----------------------------------------
// Page Testimonials Meta box Options      -
// -----------------------------------------
if ( class_exists( 'WooCommerce' ) ) {
	$options[] = array(
		'id'        => '_custom_post_woo_options',
		'title'     => esc_html__( 'Post Meta Data', 'casano-toolkit' ),
		'post_type' => 'post',
		'context'   => 'normal',
		'priority'  => 'high',
		'sections'  => array(
			array(
				'name'   => 'post-format-setting',
				'title'  => esc_html__( 'Post Format Settings', 'casano-toolkit' ),
				'icon'   => 'fa fa-picture-o',
				'fields' => array(
					array(
						'id'    => 'audio-video-url',
						'type'  => 'text',
						'title' => esc_html__( 'Upload Video or Audio Url', 'casano-toolkit' ),
						'desc'  => esc_html__( 'Using when you choose post format video or audio.' ),
					),
					array(
						'id'          => 'post-gallery',
						'type'        => 'gallery',
						'title'       => esc_html__( 'Gallery', 'casano-toolkit' ),
						'desc'        => esc_html__( 'Using when you choose post format gallery.' ),
						'add_title'   => esc_html__( 'Add Images', 'casano-toolkit' ),
						'edit_title'  => esc_html__( 'Edit Images', 'casano-toolkit' ),
						'clear_title' => esc_html__( 'Remove Images', 'casano-toolkit' ),
					),
					array(
						'id'    => 'page_extra_class',
						'type'  => 'text',
						'title' => esc_html__( 'Extra Class', 'casano-toolkit' ),
					),
				),
			),
		),
	);
	$options[] = array(
		'id'        => '_custom_product_woo_options',
		'title'     => esc_html__( 'Product Options', 'casano-toolkit' ),
		'post_type' => 'product',
		'context'   => 'side',
		'priority'  => 'high',
		'sections'  => array(
			array(
				'name'   => 'meta_product_option',
				'fields' => array(
					array(
						'id'          => '360gallery',
						'type'        => 'gallery',
						'title'       => esc_html__( 'Gallery 360', 'casano-toolkit' ),
						'add_title'   => esc_html__( 'Add Images', 'casano-toolkit' ),
						'edit_title'  => esc_html__( 'Edit Images', 'casano-toolkit' ),
						'clear_title' => esc_html__( 'Remove Images', 'casano-toolkit' ),
					),
					array(
						'id'    => 'youtube_url',
						'type'  => 'text',
						'title' => esc_html__( 'Product Video', 'casano-toolkit' ),
						'desc'  => esc_html__( 'Supported video Youtube, Vimeo .' ),
					),
				),
			),
		
		
		),
	);
}
// -----------------------------------------
// Page Side Meta box Options              -
// -----------------------------------------
$options[] = array(
	'id'        => '_custom_page_side_options',
	'title'     => esc_html__( 'Custom Page Side Options', 'casano-toolkit' ),
	'post_type' => 'page',
	'context'   => 'side',
	'priority'  => 'default',
	'sections'  => array(
		array(
			'name'   => 'page_option',
			'fields' => array(
				array(
					'id'      => 'sidebar_page_layout',
					'type'    => 'image_select',
					'title'   => esc_html__( 'Single Post Sidebar Position', 'casano-toolkit' ),
					'desc'    => esc_html__( 'Select sidebar position on Page.', 'casano-toolkit' ),
					'options' => array(
						'left'  => CASANO_TOOLKIT_URL . '/includes/core/assets/images/left-sidebar.png',
						'right' => CASANO_TOOLKIT_URL . '/includes/core/assets/images/right-sidebar.png',
						'full'  => CASANO_TOOLKIT_URL . '/includes/core/assets/images/default-sidebar.png',
					),
					'default' => 'left',
				),
				array(
					'id'         => 'page_sidebar',
					'type'       => 'select',
					'title'      => esc_html__( 'Page Sidebar', 'casano-toolkit' ),
					'options'    => $data_meta->sidebars,
					'default'    => 'primary_sidebar',
					'dependency' => array( 'sidebar_page_layout_full', '==', false ),
				),
				array(
					'id'    => 'page_extra_class',
					'type'  => 'text',
					'title' => esc_html__( 'Extra Class', 'casano-toolkit' ),
				),
			),
		),
	
	),
);
// -----------------------------------------
// Post Side Meta box Options              -
// -----------------------------------------

CSFramework_Metabox::instance( $options );

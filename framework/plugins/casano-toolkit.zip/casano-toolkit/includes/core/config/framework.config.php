<?php if ( ! defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
if ( ! class_exists( 'Casano_ThemeOption' ) ) {
	class Casano_ThemeOption {
		public $sidebars        = array();
		public $header_options  = array();
		public $product_options = array();

		public function __construct() {
			$this->get_sidebars();
			$this->get_footer_options();
			$this->get_header_options();
			$this->casano_rev_slide_options_for_redux();
			$this->get_product_options();
			$this->init_settings();
			add_action( 'admin_bar_menu', array( $this, 'casano_custom_menu' ), 1000 );
		}

		public function get_header_options() {
			$layoutDir      = get_template_directory() . '/templates/headers/';
			$header_options = array();

			if ( is_dir( $layoutDir ) ) {
				$files = scandir( $layoutDir );
				if ( $files && is_array( $files ) ) {
					$option = '';
					foreach ( $files as $file ) {
						if ( $file != '.' && $file != '..' ) {
							$fileInfo = pathinfo( $file );
							if ( $fileInfo['extension'] == 'php' && $fileInfo['basename'] != 'index.php' ) {
								$file_data                    = get_file_data( $layoutDir . $file, array( 'Name' => 'Name' ) );
								$file_name                    = str_replace( 'header-', '', $fileInfo['filename'] );
								$header_options[ $file_name ] = array(
									'title'   => $file_data['Name'],
									'preview' => get_template_directory_uri() . '/templates/headers/header-' . $file_name . '.jpg',
								);
							}
						}
					}
				}
			}
			$this->header_options = $header_options;
		}

		public function get_social_options() {
			$socials     = array();
			$all_socials = cs_get_option( 'user_all_social' );
			if ( $all_socials ) {
				foreach ( $all_socials as $key => $social ) {
					$socials[ $key ] = $social['title_social'];
				}
			}

			return $socials;
		}

		public function get_footer_options() {
			$footer_options = array(
				'default' => esc_html__( 'Default', 'casano-toolkit' ),
			);
			$layoutDir      = get_template_directory() . '/templates/footers/';
			if ( is_dir( $layoutDir ) ) {
				$files = scandir( $layoutDir );
				if ( $files && is_array( $files ) ) {
					$option = '';
					foreach ( $files as $file ) {
						if ( $file != '.' && $file != '..' ) {
							$fileInfo = pathinfo( $file );
							if ( $fileInfo['extension'] == 'php' && $fileInfo['basename'] != 'index.php' ) {
								$file_data                    = get_file_data( $layoutDir . $file, array( 'Name' => 'Name' ) );
								$file_name                    = str_replace( 'footer-', '', $fileInfo['filename'] );
								$footer_options[ $file_name ] = $file_data['Name'];
							}
						}
					}
				}
			}
			$this->footer_options = $footer_options;
		}

		/* GET REVOLOTION */
		public function casano_rev_slide_options_for_redux() {
			$casano_herosection_revolutions = array( '' => esc_html__( '--- Choose Revolution Slider ---', 'casano-toolkit' ) );
			if ( class_exists( 'RevSlider' ) ) {
				global $wpdb;
				if ( shortcode_exists( 'rev_slider' ) ) {
					$rev_sql  = $wpdb->prepare(
						"SELECT *
                    FROM {$wpdb->prefix}revslider_sliders
                    WHERE %d", 1
					);
					$rev_rows = $wpdb->get_results( $rev_sql );
					if ( count( $rev_rows ) > 0 ) {
						foreach ( $rev_rows as $rev_row ):
							$casano_herosection_revolutions[ $rev_row->alias ] = $rev_row->title;
						endforeach;
					}
				}
			}

			$this->herosection_options = $casano_herosection_revolutions;
		}

		public function get_product_options() {
			$layoutDir       = get_template_directory() . '/woocommerce/product-styles/';
			$product_options = array();

			if ( is_dir( $layoutDir ) ) {
				$files = scandir( $layoutDir );
				if ( $files && is_array( $files ) ) {
					$option = '';
					foreach ( $files as $file ) {
						if ( $file != '.' && $file != '..' ) {
							$fileInfo = pathinfo( $file );
							if ( $fileInfo['extension'] == 'php' && $fileInfo['basename'] != 'index.php' ) {
								$file_data                     = get_file_data( $layoutDir . $file, array( 'Name' => 'Name' ) );
								$file_name                     = str_replace( 'content-product-style-', '', $fileInfo['filename'] );
								$product_options[ $file_name ] = array(
									'title'   => $file_data['Name'],
									'preview' => get_template_directory_uri() . '/woocommerce/product-styles/content-product-style-' . $file_name . '.jpg',
								);
							}
						}
					}
				}
			}
			$this->product_options = $product_options;
		}

		public function casano_attributes_options() {
			$attributes     = array();
			$attributes_tax = array();
			if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
				$attributes_tax = wc_get_attribute_taxonomies();
			}
			if ( is_array( $attributes_tax ) && count( $attributes_tax ) > 0 ) {
				foreach ( $attributes_tax as $attribute ) {
					$attribute_name                = 'pa_' . $attribute->attribute_name;
					$attributes[ $attribute_name ] = $attribute->attribute_label;
				}
			}

			return $attributes;
		}

		public function get_sidebars() {
			global $wp_registered_sidebars;
			foreach ( $wp_registered_sidebars as $sidebar ) {
				$sidebars[ $sidebar['id'] ] = $sidebar['name'];
			}
			$this->sidebars = $sidebars;
		}

		public function casano_custom_menu() {
			global $wp_admin_bar;
			if ( ! is_super_admin() || ! is_admin_bar_showing() ) {
				return;
			}
			// Add Parent Menu
			$argsParent = array(
				'id'    => 'theme_option',
				'title' => esc_html__( 'Theme Options', 'casano-toolkit' ),
				'href'  => admin_url( 'admin.php?page=casano-toolkit' ),
			);
			$wp_admin_bar->add_menu( $argsParent );
		}

		public function init_settings() {
			// ===============================================================================================
			// -----------------------------------------------------------------------------------------------
			// FRAMEWORK SETTINGS
			// -----------------------------------------------------------------------------------------------
			// ===============================================================================================
			$settings = array(
				'menu_title'      => 'Theme Options',
				'menu_type'       => 'submenu', // menu, submenu, options, theme, etc.
				'menu_slug'       => 'casano-toolkit',
				'ajax_save'       => true,
				'menu_parent'     => 'casano_menu',
				'show_reset_all'  => true,
				'menu_position'   => 2,
				'framework_title' => '<a href="http://casano.famithemes.com/" target="_blank"><img src="' . esc_url( CASANO_TOOLKIT_URL . 'assets/images/logo-backend.png' ) . '" alt=""></a> <small>by <a href="https://famithemes.com" target="_blank">FamiThemes</a></small>',
			);

			// ===============================================================================================
			// -----------------------------------------------------------------------------------------------
			// FRAMEWORK OPTIONS
			// -----------------------------------------------------------------------------------------------
			// ===============================================================================================
			$options = array();

			// ----------------------------------------
			// a option section for options overview  -
			// ----------------------------------------
			$options[] = array(
				'name'     => 'general',
				'title'    => esc_html__( 'General', 'casano-toolkit' ),
				'icon'     => 'fa fa-wordpress',
				'sections' => array(
					array(
						'name'   => 'main_settings',
						'title'  => esc_html__( 'Main Settings', 'casano-toolkit' ),
						'fields' => array(
							array(
								'id'        => 'casano_logo',
								'type'      => 'image',
								'title'     => esc_html__( 'Logo', 'casano-toolkit' ),
								'add_title' => esc_html__( 'Add Logo', 'casano-toolkit' ),
								'desc'      => esc_html__( 'Add custom logo for your website.', 'casano-toolkit' ),
							),
                            array(
                                'id'      => 'width_logo',
                                'type'    => 'number',
                                'default' => '112',
                                'title'   => esc_html__( 'Width Logo', 'casano-toolkit' ),
                                'desc'    => esc_html__( 'Unit PX', 'casano-toolkit' )
                            ),
							array(
								'id'      => 'casano_main_color',
								'type'    => 'color_picker',
								'title'   => esc_html__( 'Main Color', 'casano-toolkit' ),
								'default' => '#2dbbf0',
								'rgba'    => true,
							),
							array(
								'id'      => 'casano_body_text_color',
								'type'    => 'color_picker',
								'title'   => esc_html__( 'Body Text Color', 'casano-toolkit' ),
								'default' => '#979797',
								'rgba'    => true,
							),
							array(
								'id'    => 'gmap_api_key',
								'type'  => 'text',
								'title' => esc_html__( 'Google Map API Key', 'casano-toolkit' ),
								'desc'  => wp_kses( sprintf( __( 'Enter your Google Map API key. <a href="%s" target="_blank">How to get?</a>', 'casano-toolkit' ), 'https://developers.google.com/maps/documentation/javascript/get-api-key' ), array(
									'a' => array(
										'href'   => array(),
										'target' => array()
									)
								) ),
							),
							array(
								'id'         => 'load_gmap_js_target',
								'type'       => 'select',
								'title'      => esc_html__( 'Load GMap JS On', 'casano-toolkit' ),
								'options'    => array(
									'all_pages'      => esc_html__( 'All Pages', 'casano-toolkit' ),
									'selected_pages' => esc_html__( 'Selected Pages', 'casano-toolkit' ),
									'disabled'       => esc_html__( 'Don\'t Load Gmap JS', 'casano-toolkit' ),
								),
								'default'    => 'all_pages',
								'dependency' => array( 'gmap_api_key', '!=', '' ),
							),
							array(
								'id'         => 'load_gmap_js_on',
								'type'       => 'select',
								'title'      => esc_html__( 'Select Pages To Load GMap JS', 'casano-toolkit' ),
								'options'    => 'pages',
								'query_args' => array(
									'post_type'      => 'page',
									'orderby'        => 'post_date',
									'order'          => 'ASC',
									'posts_per_page' => - 1
								),
								'attributes' => array(
									'multiple' => 'multiple',
									'style'    => 'width: 500px; height: 125px;',
								),
								'class'      => 'chosen',
								'desc'       => esc_html__( 'Load Google Map JS on selected pages', 'casano-toolkit' ),
								'dependency' => array(
									'gmap_api_key|load_gmap_js_target',
									'!=|==',
									'|selected_pages'
								),
							),
							array(
								'id'      => 'casano_enable_lazy',
								'type'    => 'switcher',
								'title'   => esc_html__( 'Lazy Load Images', 'casano-toolkit' ),
								'default' => true,
								'desc'    => esc_html__( 'Enables lazy load to reduce page requests.', 'casano-toolkit' ),
							),
							array(
								'id'      => 'animation_on_scroll',
								'type'    => 'switcher',
								'title'   => esc_html__( 'Animation On Scroll', 'casano-toolkit' ),
								'default' => false,
								'desc'    => esc_html__( 'If enabled, will active the animation of elements when scrolling. You also need to select the animation when scrolling the mouse for each element when editing the article', 'casano-toolkit' ),
							),
							array(
								'id'      => 'enable_smooth_scroll',
								'type'    => 'switcher',
								'title'   => esc_html__( 'Smooth Scroll', 'casano-toolkit' ),
								'default' => false,
								'desc'    => esc_html__( 'Turn on if you want to smooth out when scrolling', 'casano-toolkit' ),
							),
						),
					),
				),
			);
			$options[] = array(
				'name'   => 'newsletter',
				'title'  => esc_html__( 'Newsletter Popup', 'casano-toolkit' ),
				'icon'   => 'fa fa-envelope-o',
				'fields' => array(
					array(
						'id'      => 'enable_newsletter',
						'type'    => 'switcher',
						'title'   => esc_html__( 'Enable Newsletter', 'casano-toolkit' ),
						'default' => true,
					),
					array(
						'id'         => 'casano_newsletter_popup',
						'type'       => 'select',
						'title'      => esc_html__( 'Select Newsletter Popup', 'casano-toolkit' ),
						'options'    => 'posts',
						'value'      => 'The title1 bar',
						'dependency' => array( 'enable_newsletter', '==', true ),
						'query_args' => array(
							'post_type'      => 'newsletter',
							'orderby'        => 'post_date',
							'order'          => 'ASC',
							'posts_per_page' => - 1
						),

					),
					array(
						'id'         => 'disable_on_mobile',
						'type'       => 'switcher',
						'title'      => esc_html__( 'On Mobile', 'casano-toolkit' ),
						'default'    => false,
						'dependency' => array( 'enable_newsletter', '==', true ),
					),

				),
			);
			$options[] = array(
				'name'     => 'header',
				'title'    => esc_html__( 'Header Settings', 'casano-toolkit' ),
				'icon'     => 'fa fa-folder-open-o',
				'sections' => array(
					array(
						'name'   => 'header_general_settings',
						'title'  => esc_html__( 'General Header Settings', 'casano-toolkit' ),
						'fields' => array(
							array(
								'id'      => 'enable_sticky_menu',
								'type'    => 'select',
								'title'   => esc_html__( 'Sticky Header', 'casano-toolkit' ),
								'options' => array(
									'none'  => esc_html__( 'Disable', 'casano-toolkit' ),
									'smart' => esc_html__( 'Sticky Header', 'casano-toolkit' ),
								),
								'default' => 'none',
							),
							array(
								'id'      => 'casano_used_header',
								'type'    => 'select_preview',
								'title'   => esc_html__( 'Header Layout', 'casano-toolkit' ),
								'desc'    => esc_html__( 'Select a header layout', 'casano-toolkit' ),
								'options' => $this->header_options,
								'default' => 'style-02',
							),
							array(
								'id'      => 'header_position',
								'type'    => 'select',
								'title'   => esc_html__( 'Header Type', 'casano-toolkit' ),
								'options' => array(
									'relative' => esc_html__( 'Header No Transparent', 'casano-toolkit' ),
									'absolute' => esc_html__( 'Header Transparent', 'casano-toolkit' ),
								),
								'default' => 'relative',
							),
                            array(
                                'id'      => 'header_color',
                                'type'    => 'select',
                                'title'   => esc_html__( 'Header Color', 'casano-toolkit' ),
                                'options' => array(
                                    'dark'    => esc_html__( 'Header Text Dark', 'casano-toolkit' ),
                                    'light'   => esc_html__( 'Header Text Light', 'casano-toolkit' ),
                                ),
                                'default' => 'dark',
                            ),
						),
					),
					array(
						'name'   => 'page_banner_settings',
						'title'  => esc_html__( 'Page Banner Settings', 'casano-toolkit' ),
						'fields' => array(
							array(
								'id'      => 'page_banner_type',
								'type'    => 'select',
								'title'   => esc_html__( 'Banner Type', 'casano-toolkit' ),
								'options' => array(
									'has_background' => esc_html__( 'Has Background', 'casano-toolkit' ),
									'no_background'  => esc_html__( 'No Background ', 'casano-toolkit' ),
								),
								'default' => 'has_background'
							),
							array(
								'id'         => 'page_banner_image',
								'type'       => 'image',
								'title'      => esc_html__( 'Banner Image', 'casano-toolkit' ),
								'add_title'  => esc_html__( 'Upload', 'casano-toolkit' ),
								'dependency' => array( 'page_banner_type', '==', 'has_background' ),
							),
							array(
								'id'         => 'page_banner_full_width',
								'type'       => 'switcher',
								'title'      => esc_html__( 'Banner Full Width', 'casano-toolkit' ),
								'default'    => true,
								'dependency' => array( 'page_banner_type', '==', 'has_background' ),
							),
							array(
								'id'      => 'page_height_banner',
								'type'    => 'number',
								'title'   => esc_html__( 'Banner Height', 'casano-toolkit' ),
								'default' => '420'
							),
						)
					),
					array(
						'name'   => 'header_mobile',
						'title'  => esc_html__( 'Header Mobile', 'casano-toolkit' ),
						'fields' => array(
							array(
								'id'      => 'enable_header_mobile',
								'type'    => 'switcher',
								'title'   => esc_html__( 'Enable Header Mobile', 'casano-toolkit' ),
								'default' => false,
							),
                            array(
                                'id'         => 'casano_logo_mobile',
                                'type'       => 'image',
                                'title'      => esc_html__( 'Mobile Logo', 'casano-toolkit' ),
                                'add_title'  => esc_html__( 'Add Mobile Logo', 'casano-toolkit' ),
                                'desc'       => esc_html__( 'Add custom logo for mobile. If no mobile logo is selected, the default logo will be used or custom logo if placed in the page', 'casano-toolkit' ),
                                'dependency' => array( 'enable_header_mobile', '==', true )
                            ),
                            array(
                                'id'         => 'width_logo_mobile',
                                'type'       => 'number',
                                'default'    => '112',
                                'title'      => esc_html__( 'Width Logo', 'casano-toolkit' ),
                                'desc'       => esc_html__( 'Unit PX', 'casano-toolkit' ),
                                'dependency' => array( 'enable_header_mobile', '==', true )
                            ),
							array(
								'id'         => 'enable_header_mini_cart_mobile',
								'type'       => 'switcher',
								'title'      => esc_html__( 'Show Mini Cart Icon', 'casano-toolkit' ),
								'desc'       => esc_html__( 'Show/Hide header mini cart icon on mobile', 'casano-toolkit' ),
								'default'    => true,
								'on'         => esc_html__( 'On', 'casano-toolkit' ),
								'off'        => esc_html__( 'Off', 'casano-toolkit' ),
								'dependency' => array( 'enable_header_mobile', '==', true )
							),
							array(
								'id'         => 'enable_header_product_search_mobile',
								'type'       => 'switcher',
								'title'      => esc_html__( 'Show Products Search Icon', 'casano-toolkit' ),
								'desc'       => esc_html__( 'Show/Hide header product search icon on mobile', 'casano-toolkit' ),
								'default'    => true,
								'on'         => esc_html__( 'On', 'casano-toolkit' ),
								'off'        => esc_html__( 'Off', 'casano-toolkit' ),
								'dependency' => array( 'enable_header_mobile', '==', true )
							),
							array(
								'id'         => 'enable_wishlist_mobile',
								'type'       => 'switcher',
								'title'      => esc_html__( 'Show Wish List Icon', 'casano-toolkit' ),
								'desc'       => esc_html__( 'Show/Hide wish list icon on siding menu mobile', 'casano-toolkit' ),
								'default'    => false,
								'on'         => esc_html__( 'Show', 'casano-toolkit' ),
								'off'        => esc_html__( 'Hide', 'casano-toolkit' ),
								'dependency' => array( 'enable_header_mobile', '==', true )
							),
							array(
								'id'         => 'enable_lang_mobile',
								'type'       => 'switcher',
								'title'      => esc_html__( 'Show Languges and Currency', 'casano-toolkit' ),
								'desc'       => esc_html__( 'Show/Hide Languges and Currency on siding menu mobile', 'casano-toolkit' ),
								'default'    => false,
								'on'         => esc_html__( 'Show', 'casano-toolkit' ),
								'off'        => esc_html__( 'Hide', 'casano-toolkit' ),
								'dependency' => array( 'enable_header_mobile', '==', true )
							),
							array(
								'id'         => 'enable_sticky_mobile',
								'type'       => 'switcher',
								'title'      => esc_html__( 'Show Sticky Menu', 'casano-toolkit' ),
								'default'    => false,
								'on'         => esc_html__( 'Turn On', 'casano-toolkit' ),
								'off'        => esc_html__( 'Turn Off', 'casano-toolkit' ),
								'dependency' => array( 'enable_header_mobile', '==', true )
							),
						),
					),
				)
			);
			$options[] = array(
				'name'   => 'footer',
				'title'  => esc_html__( 'Footer Settings', 'casano-toolkit' ),
				'icon'   => 'fa fa-folder-open-o',
				'fields' => array(
					array(
						'id'         => 'casano_footer_options',
						'type'       => 'select',
						'title'      => esc_html__( 'Select Footer Builder', 'casano-toolkit' ),
						'options'    => 'posts',
						'query_args' => array(
							'post_type'      => 'footer',
							'orderby'        => 'post_date',
							'order'          => 'ASC',
							'posts_per_page' => - 1
						),
					),
				),
			);

			$options[] = array(
				'name'     => 'blog',
				'title'    => esc_html__( 'Blog Settings', 'casano-toolkit' ),
				'icon'     => 'fa fa-rss',
				'sections' => array(
					array(
						'name'   => 'blog_page',
						'title'  => esc_html__( 'Blog Page', 'casano-toolkit' ),
						'fields' => array(
							array(
								'type'    => 'subheading',
								'content' => esc_html__( 'General Settings', 'casano-toolkit' ),
							),
                            array(
                                'id'    => 'blog_logo',
                                'type'  => 'image',
                                'title' => esc_html__( 'Blog Logo', 'casano-toolkit' ),
                            ),
                            array(
                                'id'    => 'blog_header_color',
                                'type'    => 'select',
                                'options' => array(
                                    'dark'  => esc_html__( 'Header Text Dark', 'casano-toolkit' ),
                                    'light' => esc_html__( 'Header Text Light', 'casano-toolkit' ),
                                ),
                                'default' => 'dark',
                                'title' => esc_html__( 'Blog Header Color', 'casano-toolkit' ),
                            ),
                            array(
                                'id'    => 'blog_header_position',
                                'type'    => 'select',
                                'options' => array(
                                    'relative'  => esc_html__( 'No Transparent', 'casano-toolkit' ),
                                    'absolute' => esc_html__( 'Transparent', 'casano-toolkit' ),
                                ),
                                'default' => 'relative',
                                'title' => esc_html__( 'Blog Header Position', 'casano-toolkit' ),
                            ),
							array(
								'id'         => 'blog-style',
								'type'       => 'image_select',
								'title'      => esc_html__( 'Blog Style', 'casano-toolkit' ),
								'radio'      => true,
								'options'    => array(
									'standard' => CS_URI . '/assets/images/layout/standard.png',
									'classic'  => CS_URI . '/assets/images/layout/classic.png',
									'grid'     => CS_URI . '/assets/images/layout/grid.png',
								),
								'default'    => 'standard',
								'attributes' => array(
									'data-depend-id' => 'blog-style',
								),
							),
							array(
								'id'         => 'casano_blog_layout',
								'type'       => 'image_select',
								'title'      => esc_html__( 'Blog Sidebar Position', 'casano-toolkit' ),
								'desc'       => esc_html__( 'Select sidebar position on Blog.', 'casano-toolkit' ),
								'options'    => array(
									'left'  => CASANO_TOOLKIT_URL . '/includes/core/assets/images/left-sidebar.png',
									'right' => CASANO_TOOLKIT_URL . '/includes/core/assets/images/right-sidebar.png',
									'full'  => CASANO_TOOLKIT_URL . '/includes/core/assets/images/default-sidebar.png',
								),
								'default'    => 'full',
							),
                            array(
                                'id'         => 'blog_sidebar',
                                'type'       => 'select',
                                'title'      => esc_html__( 'Blog Sidebar', 'casano-toolkit' ),
                                'options'    => $this->sidebars,
                                'default'    => 'primary_sidebar',
                                'dependency' => array( 'casano_blog_layout_full', '==', false ),
                            ),
                            array(
                                'id'    => 'enable_except_post',
                                'type'  => 'switcher',
                                'title' => esc_html__( 'Enable Except Post', 'casano' ),
                                'dependency' => array( 'blog-style', '==', 'standard' ),
                            ),
						),
					),
					array(
						'name'   => 'single_post',
						'title'  => 'Single Post',
						'fields' => array(
							array(
								'id'      => 'sidebar_single_post_position',
								'type'    => 'image_select',
								'title'   => 'Single Post Sidebar Position',
								'desc'    => 'Select sidebar position on Single Post.',
								'options' => array(
									'left'  => CASANO_TOOLKIT_URL . '/includes/core/assets/images/left-sidebar.png',
									'right' => CASANO_TOOLKIT_URL . '/includes/core/assets/images/right-sidebar.png',
									'full'  => CASANO_TOOLKIT_URL . '/includes/core/assets/images/default-sidebar.png',
								),
								'default' => 'left',
							),
							array(
								'id'         => 'single_post_sidebar',
								'type'       => 'select',
								'title'      => 'Single Post Sidebar',
								'options'    => $this->sidebars,
								'default'    => 'primary_sidebar',
								'dependency' => array( 'sidebar_single_post_position_full', '==', false ),
							),
                            array(
                                'id'    => 'enable_share_post',
                                'type'  => 'switcher',
                                'title' => esc_html__( 'Enable Share Button', 'casano' ),
                            ),
						),
					),
				),
			);
			if ( class_exists( 'WooCommerce' ) ) {
				$options[] = array(
					'name'     => 'wooCommerce',
					'title'    => esc_html__( 'WooCommerce', 'casano-toolkit' ),
					'icon'     => 'fa fa-shopping-cart',
					'sections' => array(
						array(
							'name'   => 'shop_product',
							'title'  => esc_html__( 'General Settings', 'casano-toolkit' ),
							'fields' => array(
								array(
									'type'    => 'subheading',
									'content' => esc_html__( 'Shop Settings', 'casano-toolkit' ),
								),
								array(
									'id'    => 'shop_logo',
									'type'  => 'image',
									'title' => esc_html__( 'Shop Logo', 'casano-toolkit' ),
									'desc'    => esc_html__( 'Logo for Shop page, product categories page, product tags page', 'casano-toolkit' ),
								),
								array(
									'id'      => 'shop_header_position',
									'type'    => 'select',
									'title'   => esc_html__( 'Shop Header Type', 'casano-toolkit' ),
									'options' => array(
										'relative' => esc_html__( 'Header No Transparent', 'casano-toolkit' ),
										'absolute' => esc_html__( 'Header Transparent', 'casano-toolkit' ),
									),
									'default' => 'relative',
								),
								array(
									'id'      => 'shop_header_color',
									'type'    => 'select',
									'title'   => esc_html__( 'Shop Header Color', 'casano-toolkit' ),
									'options' => array(
										'dark'    => esc_html__( 'Header Text Dark', 'casano-toolkit' ),
										'light'   => esc_html__( 'Header Text Light', 'casano-toolkit' ),
									),
									'default' => 'dark',
								),
								array(
									'id'      => 'shop_banner_type',
									'type'    => 'select',
									'title'   => esc_html__( 'Shop Banner Type', 'casano-toolkit' ),
									'options' => array(
										'has_background' => esc_html__( 'Has Background', 'casano-toolkit' ),
										'no_background'  => esc_html__( 'No Background ', 'casano-toolkit' ),
									),
									'default' => 'no_background',
									'desc'    => esc_html__( 'Banner for Shop page, archive, search results page...', 'casano-toolkit' ),
								),
								array(
									'id'         => 'shop_banner_image',
									'type'       => 'image',
									'title'      => esc_html__( 'Banner Image', 'casano-toolkit' ),
									'add_title'  => esc_html__( 'Upload', 'casano-toolkit' ),
									'dependency' => array( 'shop_banner_type', '==', 'has_background' ),
								),
								array(
									'id'      => 'shop_banner_height',
									'type'    => 'number',
									'title'   => esc_html__( 'Banner Height', 'casano-toolkit' ),
									'default' => '420',
								),
								array(
									'id'      => 'shop_panel',
									'type'    => 'switcher',
									'title'   => esc_html__( 'Shop Top Categories', 'casano-toolkit' ),
									'default' => false,
								),
								array(
									'id'             => 'style-categories',
									'type'           => 'select',
									'title'          => esc_html__( 'Shop Categories Style', 'casano-toolkit' ),
									'options'        => array(
										'cate-image'    => esc_html__( 'Categories Image', 'casano-toolkit' ),
										'cate-count'    => esc_html__( 'Categories List', 'casano-toolkit' ),
									),
									'default' => 'cate-image',
									'dependency'     => array( 'shop_panel', '==', true ),
								),
								array(
									'id'             => 'panel-categories',
									'type'           => 'select',
									'title'          => esc_html__( 'Select Categories', 'casano-toolkit' ),
									'options'        => 'categories',
									'query_args'     => array(
										'type'           => 'product',
										'taxonomy'       => 'product_cat',
										'orderby'        => 'post_date',
										'order'          => 'DESC',
										'posts_per_page' => - 1
									),
									'attributes'     => array(
										'multiple' => 'multiple',
										'style'    => 'width: 500px; height: 125px;',
									),
									'class'          => 'chosen',
									'default_option' => esc_html__( 'Select Categories', 'casano-toolkit' ),
									'desc'           => esc_html__( 'Product categories displayed on the shop page', 'casano-toolkit' ),
									'dependency'     => array( 'shop_panel', '==', true ),
								),
								array(
									'id'      => 'enable_shop_mobile',
									'type'    => 'switcher',
									'title'   => esc_html__( 'Shop Mobile Layout', 'casano-toolkit' ),
									'default' => true,
									'desc'    => esc_html__( 'Use the dedicated mobile interface on a real device instead of responsive. Note, this option is not available for desktop browsing and uses resize the screen.', 'casano-toolkit' ),
								),
								array(
									'id'      => 'enable_instant_product_search',
									'type'    => 'switcher',
									'title'   => esc_html__( 'Instant Products Search', 'casano-toolkit' ),
									'default' => false,
									'desc'    => esc_html__( 'Enabling "Instant Products Search" will display search results instantly as soon as you type', 'casano-toolkit' ),
								),
								array(
									'id'      => 'sidebar_shop_page_position',
									'type'    => 'image_select',
									'title'   => esc_html__( 'Shop Page Layout', 'casano-toolkit' ),
									'desc'    => esc_html__( 'Select layout for Shop Page.', 'casano-toolkit' ),
									'options' => array(
										'left'   => CASANO_TOOLKIT_URL . '/includes/core/assets/images/left-sidebar.png',
										'right'  => CASANO_TOOLKIT_URL . '/includes/core/assets/images/right-sidebar.png',
										'full'   => CASANO_TOOLKIT_URL . '/includes/core/assets/images/default-sidebar.png',
									),
									'default' => 'full',
								),
                                array(
                                    'id'      => 'filter_shop_page',
                                    'type'    => 'select',
                                    'title'   => esc_html__( 'Sidebar Filter Shop Page', 'casano-toolkit' ),
                                    'options' => array(
                                        'top_sidebar'                  => esc_html__( 'Default', 'casano-toolkit' ),
                                        'drawer_sidebar'    => esc_html__( 'Drawer Sidebar Filter', 'casano-toolkit' ),
                                        'offcanvas_sidebar' => esc_html__( 'Off Canvas Sidebar Filter', 'casano-toolkit' ),
                                    ),
                                    'default' => 'top_sidebar',
                                    'dependency' => array(
                                        'sidebar_shop_page_position_full',
                                        '==',
                                        true
                                    ),
                                ),
								array(
									'id'         => 'shop_page_sidebar',
									'type'       => 'select',
									'title'      => esc_html__( 'Shop Sidebar', 'casano-toolkit' ),
									'options'    => $this->sidebars,
									'dependency' => array(
										'sidebar_shop_page_position_full',
										'==',
										false
									),
								),
								array(
									'id'      => 'product_per_page',
									'type'    => 'number',
									'title'   => esc_html__( 'Products perpage', 'casano-toolkit' ),
									'desc'    => 'Number of products on shop page.',
									'default' => '12',
								),
								array(
									'id'      => 'shop_type',
									'type'    => 'select',
									'options' => array(
										''    => esc_html__( 'Default', 'casano-toolkit' ),
										'masonry' => esc_html__( 'Masonry', 'casano-toolkit' ),

									),
									'title'   => esc_html__( 'Choose Shop Type', 'casano-toolkit' ),
									'desc'    => esc_html__( 'Choose type for shop page.', 'casano-toolkit' ),
									'default' => '',
								),
								array(
									'id'      => 'casano_enable_loadmore',
									'type'    => 'select',
									'options' => array(
										'default'  => esc_html__( 'Default', 'casano-toolkit' ),
										'loadmore' => esc_html__( 'Load More', 'casano-toolkit' ),
										'infinity' => esc_html__( 'Infinity', 'casano-toolkit' ),

									),
									'title'   => esc_html__( 'Choose Pagination', 'casano-toolkit' ),
									'desc'    => esc_html__( 'Choose pagination type for shop page.', 'casano-toolkit' ),
									'default' => 'default',
								),
								array(
									'id'         => 'casano_shop_product_style',
									'type'       => 'select_preview',
									'title'      => esc_html__( 'Product Shop Layout', 'casano-toolkit' ),
									'desc'       => esc_html__( 'Select a Product layout in shop page', 'casano-toolkit' ),
									'options'    => $this->product_options,
									'default'    => '1',
								),
								array(
									'id'      => 'product_star_rating',
									'type'    => 'select',
									'options' => array(
										''       => esc_html__( 'Turn On', 'casano-toolkit' ),
										'nostar' => esc_html__( 'Turn Off', 'casano-toolkit' ),
									),
									'title'   => esc_html__( 'Product Star Rating', 'casano-toolkit' ),
									'default' => '',
								),
								array(
									'id'         => 'products_loop_attributes_display',
									'type'       => 'select',
									'title'      => esc_html__( 'Products Attribute Display On Loop', 'casano-toolkit' ),
									'options'    => $this->casano_attributes_options(),
									'attributes' => array(
										'multiple' => 'multiple',
										'style'    => 'width: 500px; height: 125px;',
									),
									'class'      => 'chosen',
									'default'    => array( 'pa_color' )
								),
								array(
									'type'       => 'subheading',
									'content'    => 'Grid Column Settings',
								),
								array(
									'id'         => 'enable_products_sizes',
									'type'       => 'switcher',
									'title'      => esc_html__( 'Show Products Size', 'casano-toolkit' ),
									'default'    => true,
								),
								array(
									'title'      => esc_html__( 'Items per row on Desktop( For grid mode )', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >= 1500px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_bg_items',
									'type'       => 'select',
									'default'    => '3',
									'options'    => array(
										'12' => '1 item',
										'6'  => '2 items',
										'4'  => '3 items',
										'3'  => '4 items',
										'15' => '5 items',
										'2'  => '6 items',
									),
									'dependency' => array( 'enable_products_sizes', '==', false ),
								),
								array(
									'title'      => esc_html__( 'Items per row on Desktop( For grid mode )', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >= 1200px < 1500px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_lg_items',
									'type'       => 'select',
									'default'    => '4',
									'options'    => array(
										'12' => '1 item',
										'6'  => '2 items',
										'4'  => '3 items',
										'3'  => '4 items',
										'15' => '5 items',
										'2'  => '6 items',
									),
									'dependency' => array( 'enable_products_sizes', '==', false ),
								),
								array(
									'title'      => esc_html__( 'Items per row on landscape tablet( For grid mode )', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=992px and < 1200px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_md_items',
									'type'       => 'select',
									'default'    => '4',
									'options'    => array(
										'12' => '1 item',
										'6'  => '2 items',
										'4'  => '3 items',
										'3'  => '4 items',
										'15' => '5 items',
										'2'  => '6 items',
									),
									'dependency' => array( 'enable_products_sizes', '==', false ),
								),
								array(
									'title'      => esc_html__( 'Items per row on portrait tablet( For grid mode )', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=768px and < 992px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_sm_items',
									'type'       => 'select',
									'default'    => '4',
									'options'    => array(
										'12' => '1 item',
										'6'  => '2 items',
										'4'  => '3 items',
										'3'  => '4 items',
										'15' => '5 items',
										'2'  => '6 items',
									),
									'dependency' => array( 'enable_products_sizes', '==', false ),
								),
								array(
									'title'      => esc_html__( 'Items per row on Mobile( For grid mode )', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=480  add < 768px)', 'casano-toolkit' ),
									'id'         => 'casano_woo_xs_items',
									'type'       => 'select',
									'default'    => '6',
									'options'    => array(
										'12' => '1 item',
										'6'  => '2 items',
										'4'  => '3 items',
										'3'  => '4 items',
										'15' => '5 items',
										'2'  => '6 items',
									),
									'dependency' => array( 'enable_products_sizes', '==', false ),
								),
								array(
									'title'      => esc_html__( 'Items per row on Mobile( For grid mode )', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device < 480px)', 'casano-toolkit' ),
									'id'         => 'casano_woo_ts_items',
									'type'       => 'select',
									'default'    => '12',
									'options'    => array(
										'12' => '1 item',
										'6'  => '2 items',
										'4'  => '3 items',
										'3'  => '4 items',
										'15' => '5 items',
										'2'  => '6 items',
									),
									'dependency' => array( 'enable_products_sizes', '==', false ),
								),
							),
						),
                        array(
                            'name'   => 'categories',
                            'title'  => esc_html__( 'Categories', 'casano-toolkit' ),
                            'fields' => array(
                                array(
                                    'id'    => 'enable_best_seller_on_product_cat',
                                    'type'  => 'switcher',
                                    'title' => esc_html__( 'Enable Bestseller Products', 'casano-toolkit' ),
                                ),
                                array(
                                    'id'         => 'category_banner',
                                    'type'       => 'image',
                                    'title'      => esc_html__( 'Categories banner', 'casano-toolkit' ),
                                    'desc'       => esc_html__( 'Banner in category page WooCommerce.', 'casano-toolkit' ),
                                    'dependency' => array( 'enable_best_seller_on_product_cat', '==', true ),
                                ),
                                array(
                                    'id'         => 'category_banner_url',
                                    'type'       => 'text',
                                    'default'    => '#',
                                    'title'      => esc_html__( 'Banner Url', 'casano-toolkit' ),
                                    'dependency' => array( 'enable_best_seller_on_product_cat', '==', true ),
                                ),
                            ),
                        ),
						array(
							'name'   => 'single_product',
							'title'  => esc_html__( 'Single Product', 'casano-toolkit' ),
							'fields' => array(
								array(
									'id'      => 'sidebar_product_position',
									'type'    => 'image_select',
									'title'   => esc_html__( 'Single Product Sidebar Position', 'casano-toolkit' ),
									'desc'    => esc_html__( 'Select sidebar position on single product page.', 'casano-toolkit' ),
									'options' => array(
										'left'  => CASANO_TOOLKIT_URL . '/includes/core/assets/images/left-sidebar.png',
										'right' => CASANO_TOOLKIT_URL . '/includes/core/assets/images/right-sidebar.png',
										'full'  => CASANO_TOOLKIT_URL . '/includes/core/assets/images/default-sidebar.png',
									),
									'default' => 'left',
								),
								array(
									'id'      => 'enable_single_product_mobile',
									'type'    => 'switcher',
									'title'   => esc_html__( 'Product Mobile Layout', 'casano-toolkit' ),
									'default' => true,
									'desc'    => esc_html__( 'Use the dedicated mobile interface on a real device instead of responsive. Note, this option is not available for desktop browsing and uses resize the screen.', 'casano-toolkit' ),
								),
								array(
									'id'      => 'enable_info_product_single',
									'type'    => 'switcher',
									'title'   => esc_html__( 'Sticky Info Product Single', 'casano-toolkit' ),
									'default' => true,
									'desc'    => esc_html__( 'On or Off Sticky Info Product Single.', 'casano-toolkit' ),
								),
								array(
									'id'         => 'single_product_sidebar',
									'type'       => 'select',
									'title'      => esc_html__( 'Single Product Sidebar', 'casano-toolkit' ),
									'options'    => $this->sidebars,
									'dependency' => array( 'sidebar_product_position_full', '==', false ),
								),
								array(
									'id'      => 'casano_woo_single_product_layout',
									'type'    => 'select',
									'title'   => esc_html__( 'Choose Single Style', 'casano-toolkit' ),
									'desc'    => esc_html__( 'Choose Single Product Style', 'casano-toolkit' ),
									'options' => array(
										'default'           => esc_html__( 'Default', 'casano-toolkit' ),
										'vertical_thumnail' => esc_html__( 'Thumbnail Vertical', 'casano-toolkit' ),
										'sticky_detail'     => esc_html__( 'Sticky Detail', 'casano-toolkit' ),
										'gallery_detail'    => esc_html__( 'Gallery Detail', 'casano-toolkit' ),
										'with_background'   => esc_html__( 'With Background', 'casano-toolkit' ),
										'slider_large'      => esc_html__( 'Slider large', 'casano-toolkit' ),
										'center_slider'     => esc_html__( 'Center Slider', 'casano-toolkit' ),
									),
									'default' => 'vertical_thumnail',
								),
								array(
									'id'         => 'single_product_img_bg_color',
									'type'       => 'color_picker',
									'title'      => esc_html__( 'Image Background Color', 'casano-toolkit' ),
									'default'    => 'rgba(0,0,0,0)',
									'rgba'       => true,
									'dependency' => array(
										'casano_woo_single_product_layout',
										'==',
										'with_background'
									),
									'desc'       => esc_html__( 'For "Big Images" style only. Default: transparent', 'casano-toolkit' ),
								),
								array(
									'id'      => 'enable_single_product_sharing',
									'type'    => 'switcher',
									'title'   => esc_html__( 'Enable Product Sharing', 'casano-toolkit' ),
									'default' => false,
								),
								array(
									'id'         => 'enable_single_product_sharing_fb',
									'type'       => 'switcher',
									'title'      => esc_html__( 'Facebook Sharing', 'casano-toolkit' ),
									'default'    => true,
									'dependency' => array( 'enable_single_product_sharing', '==', true ),
								),
								array(
									'id'         => 'enable_single_product_sharing_tw',
									'type'       => 'switcher',
									'title'      => esc_html__( 'Twitter Sharing', 'casano-toolkit' ),
									'default'    => true,
									'dependency' => array( 'enable_single_product_sharing', '==', true ),
								),
								array(
									'id'         => 'enable_single_product_sharing_pinterest',
									'type'       => 'switcher',
									'title'      => esc_html__( 'Pinterest Sharing', 'casano-toolkit' ),
									'default'    => true,
									'dependency' => array( 'enable_single_product_sharing', '==', true ),
								),
								array(
									'id'         => 'enable_single_product_sharing_gplus',
									'type'       => 'switcher',
									'title'      => esc_html__( 'Google Plus Sharing', 'casano-toolkit' ),
									'default'    => true,
									'dependency' => array( 'enable_single_product_sharing', '==', true ),
								),
							),
						),
                        array(
                            'name'   => 'extend_single_product',
                            'title'  => esc_html__( 'Extend Single Products', 'casano-toolkit' ),
                            'fields' => array(
                                array(
                                    'id'         => 'enable_extend_single_product',
                                    'type'       => 'switcher',
                                    'title'      => esc_html__( 'Enable Extend Single Products', 'casano-toolkit' ),
                                    'default'    => false,
                                ),
                            ),
                        ),
						array(
							'name'   => 'cross_sell',
							'title'  => esc_html__( 'Cross Sell', 'casano-toolkit' ),
							'fields' => array(
								array(
									'id'      => 'enable_cross_sell',
									'type'    => 'select',
									'options' => array(
										'yes' => esc_html__( 'Yes', 'casano-toolkit' ),
										'no'  => esc_html__( 'No', 'casano-toolkit' ),
									),
									'title'   => esc_html__( 'Enable Cross Sell', 'casano-toolkit' ),
									'default' => 'yes',
								),
								array(
									'title'      => esc_html__( 'Cross sell title', 'casano-toolkit' ),
									'id'         => 'casano_cross_sells_products_title',
									'type'       => 'text',
									'default'    => esc_html__( 'You may be interested in...', 'casano-toolkit' ),
									'desc'       => esc_html__( 'Cross sell title', 'casano-toolkit' ),
									'dependency' => array( 'enable_cross_sell', '==', 'yes' ),
								),

								array(
									'title'      => esc_html__( 'Cross sell items per row on Desktop', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >= 1500px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_crosssell_ls_items',
									'type'       => 'select',
									'default'    => '4',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_cross_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Cross sell items per row on Desktop', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >= 1200px < 1500px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_crosssell_lg_items',
									'type'       => 'select',
									'default'    => '4',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_cross_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Cross sell items per row on landscape tablet', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=992px and < 1200px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_crosssell_md_items',
									'type'       => 'select',
									'default'    => '3',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_cross_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Cross sell items per row on portrait tablet', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=768px and < 992px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_crosssell_sm_items',
									'type'       => 'select',
									'default'    => '2',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_cross_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Cross sell items per row on Mobile', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=480  add < 768px)', 'casano-toolkit' ),
									'id'         => 'casano_woo_crosssell_xs_items',
									'type'       => 'select',
									'default'    => '2',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_cross_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Cross sell items per row on Mobile', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device < 480px)', 'casano-toolkit' ),
									'id'         => 'casano_woo_crosssell_ts_items',
									'type'       => 'select',
									'default'    => '1',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_cross_sell', '==', 'yes' ),
								),
							),
						),
						array(
							'name'   => 'related_product',
							'title'  => 'Related Products',
							'fields' => array(
								array(
									'id'      => 'enable_relate_products',
									'type'    => 'select',
									'options' => array(
										'yes' => esc_html__( 'Yes', 'casano-toolkit' ),
										'no'  => esc_html__( 'No', 'casano-toolkit' ),
									),
									'title'   => esc_html__( 'Enable Related Products', 'casano-toolkit' ),
									'default' => 'yes',
								),
								array(
									'title'      => esc_html__( 'Related products title', 'casano-toolkit' ),
									'id'         => 'casano_related_products_title',
									'type'       => 'text',
									'default'    => 'Related Products',
									'desc'       => esc_html__( 'Related products title', 'casano-toolkit' ),
									'dependency' => array( 'enable_relate_products', '==', 'yes' ),
								),
								array(
									'title'    => esc_html__( 'Limit Number Of Products', 'casano' ),
									'id'       => 'casano_related_products_perpage',
									'type'     => 'text',
									'default'  => '8',
									'validate' => 'numeric',
									'subtitle' => esc_html__( 'Number of products on shop page', 'casano' ),
								),
								array(
									'title'      => esc_html__( 'Related products items per row on Desktop', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >= 1500px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_related_ls_items',
									'type'       => 'select',
									'default'    => '4',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_relate_products', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Related products items per row on Desktop', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >= 1200px < 1500px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_related_lg_items',
									'type'       => 'select',
									'default'    => '4',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_relate_products', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Related products items per row on landscape tablet', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=992px and < 1200px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_related_md_items',
									'type'       => 'select',
									'default'    => '3',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_relate_products', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Related product items per row on portrait tablet', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=768px and < 992px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_related_sm_items',
									'type'       => 'select',
									'default'    => '2',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_relate_products', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Related products items per row on Mobile', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=480  add < 768px)', 'casano-toolkit' ),
									'id'         => 'casano_woo_related_xs_items',
									'type'       => 'select',
									'default'    => '2',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_relate_products', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Related products items per row on Mobile', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device < 480px)', 'casano-toolkit' ),
									'id'         => 'casano_woo_related_ts_items',
									'type'       => 'select',
									'default'    => '1',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_relate_products', '==', 'yes' ),
								),
							),
						),
						array(
							'name'   => 'upsells_product',
							'title'  => esc_html__( 'Up sells Products', 'casano-toolkit' ),
							'fields' => array(
								array(
									'id'      => 'enable_up_sell',
									'type'    => 'select',
									'options' => array(
										'yes' => esc_html__( 'Yes', 'casano-toolkit' ),
										'no'  => esc_html__( 'No', 'casano-toolkit' ),
									),
									'title'   => esc_html__( 'Enable Up Sell', 'casano-toolkit' ),
									'default' => 'yes',
								),
								array(
									'title'      => esc_html__( 'Up sells title', 'casano-toolkit' ),
									'id'         => 'casano_upsell_products_title',
									'type'       => 'text',
									'default'    => esc_html__( 'You may also like...', 'casano-toolkit' ),
									'desc'       => esc_html__( 'Up sells products title', 'casano-toolkit' ),
									'dependency' => array( 'enable_up_sell', '==', 'yes' ),
								),

								array(
									'title'      => esc_html__( 'Up sells items per row on Desktop', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >= 1500px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_upsell_ls_items',
									'type'       => 'select',
									'default'    => '3',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_up_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Up sells items per row on Desktop', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >= 1200px < 1500px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_upsell_lg_items',
									'type'       => 'select',
									'default'    => '3',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_up_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Up sells items per row on landscape tablet', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=992px and < 1200px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_upsell_md_items',
									'type'       => 'select',
									'default'    => '3',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_up_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Up sells items per row on portrait tablet', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=768px and < 992px )', 'casano-toolkit' ),
									'id'         => 'casano_woo_upsell_sm_items',
									'type'       => 'select',
									'default'    => '2',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_up_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Up sells items per row on Mobile', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device >=480  add < 768px)', 'casano-toolkit' ),
									'id'         => 'casano_woo_upsell_xs_items',
									'type'       => 'select',
									'default'    => '2',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_up_sell', '==', 'yes' ),
								),
								array(
									'title'      => esc_html__( 'Up sells items per row on Mobile', 'casano-toolkit' ),
									'desc'       => esc_html__( '(Screen resolution of device < 480px)', 'casano-toolkit' ),
									'id'         => 'casano_woo_upsell_ts_items',
									'type'       => 'select',
									'default'    => '1',
									'options'    => array(
										'1' => '1 item',
										'2' => '2 items',
										'3' => '3 items',
										'4' => '4 items',
										'5' => '5 items',
										'6' => '6 items',
									),
									'dependency' => array( 'enable_up_sell', '==', 'yes' ),
								),
							),
						),
					),
				);
			}

			$options[] = array(
				'name'   => 'social_settings',
				'title'  => esc_html__( 'Social Settings', 'casano-toolkit' ),
				'icon'   => 'fa fa-users',
				'fields' => array(
					array(
						'type'    => 'subheading',
						'content' => esc_html__( 'Socials Networks', 'casano-toolkit' ),
					),
					array(
						'id'              => 'user_all_social',
						'type'            => 'group',
						'title'           => esc_html__( 'Socials', 'casano-toolkit' ),
						'button_title'    => esc_html__( 'Add New Social', 'casano-toolkit' ),
						'accordion_title' => esc_html__( 'Social Settings', 'casano-toolkit' ),
						'fields'          => array(
							array(
								'id'      => 'title_social',
								'type'    => 'text',
								'title'   => esc_html__( 'Social Title', 'casano-toolkit' ),
								'default' => esc_html__( 'Facebook', 'casano-toolkit' ),
							),
							array(
								'id'      => 'link_social',
								'type'    => 'text',
								'title'   => esc_html__( 'Social Link', 'casano-toolkit' ),
								'default' => 'https://facebook.com',
							),
							array(
								'id'      => 'icon_social',
								'type'    => 'icon',
								'title'   => esc_html__( 'Social Icon', 'casano-toolkit' ),
								'default' => 'fa fa-facebook',
							),
						),
					),
				),
			);

			$options[] = array(
				'name'   => 'typography',
				'title'  => esc_html__( 'Typography Options', 'casano-toolkit' ),
				'icon'   => 'fa fa-font',
				'fields' => array(
					array(
						'id'      => 'enable_google_font',
						'type'    => 'switcher',
						'title'   => esc_html__( 'Enable Google Font', 'casano-toolkit' ),
						'default' => false,
						'on'      => esc_html__( 'Enable', 'casano-toolkit' ),
						'off'     => esc_html__( 'Disable', 'casano-toolkit' )
					),
					array(
						'id'         => 'typography_themes',
						'type'       => 'typography',
						'title'      => esc_html__( 'Body Typography', 'casano-toolkit' ),
						'default'    => array(
							'family'  => 'Open Sans',
							'variant' => '400',
							'font'    => 'google',
						),
						'dependency' => array( 'enable_google_font', '==', true )
					),
					array(
						'id'         => 'fontsize-body',
						'type'       => 'number',
						'title'      => esc_html__( 'Body Font Size', 'casano-toolkit' ),
						'default'    => '15',
						'after'      => ' <i class="cs-text-muted">px</i>',
						'dependency' => array( 'enable_google_font', '==', true )
					)
				),
			);

			$options[] = array(
				'name'   => 'backup_option',
				'title'  => esc_html__( 'Backup Options', 'casano-toolkit' ),
				'icon'   => 'fa fa-font',
				'fields' => array(
					array(
						'type'  => 'backup',
						'title' => esc_html__( 'Backup Field', 'casano-toolkit' ),
					),
				),
			);


			CSFramework::instance( $settings, $options );
		}
	}

	new Casano_ThemeOption();
}

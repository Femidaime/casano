<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Register Custom Taxonomy
function casano_toolkit_custom_taxonomies() {
	
	// Product brand
	$labels = array(
		'name'                       => _x( 'Brands', 'Taxonomy General Name', 'casano-toolkit' ),
		'singular_name'              => _x( 'Brand', 'Taxonomy Singular Name', 'casano-toolkit' ),
		'menu_name'                  => __( 'Brands', 'casano-toolkit' ),
		'all_items'                  => __( 'All Brands', 'casano-toolkit' ),
		'parent_item'                => __( 'Parent Brand', 'casano-toolkit' ),
		'parent_item_colon'          => __( 'Parent Brand:', 'casano-toolkit' ),
		'new_item_name'              => __( 'New Brand Name', 'casano-toolkit' ),
		'add_new_item'               => __( 'Add New Brand', 'casano-toolkit' ),
		'edit_item'                  => __( 'Edit Brand', 'casano-toolkit' ),
		'update_item'                => __( 'Update Brand', 'casano-toolkit' ),
		'view_item'                  => __( 'View Brand', 'casano-toolkit' ),
		'separate_items_with_commas' => __( 'Separate brands with commas', 'casano-toolkit' ),
		'add_or_remove_items'        => __( 'Add or remove brands', 'casano-toolkit' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'casano-toolkit' ),
		'popular_items'              => __( 'Popular Brands', 'casano-toolkit' ),
		'search_items'               => __( 'Search Brands', 'casano-toolkit' ),
		'not_found'                  => __( 'Not Found', 'casano-toolkit' ),
		'no_terms'                   => __( 'No brands', 'casano-toolkit' ),
		'items_list'                 => __( 'Brands list', 'casano-toolkit' ),
		'items_list_navigation'      => __( 'Brands list navigation', 'casano-toolkit' ),
	);
	$args   = array(
		'labels'            => $labels,
		'hierarchical'      => true,
		'public'            => true,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_nav_menus' => true,
		'show_tagcloud'     => true,
	);
	register_taxonomy( 'product_brand', array( 'product' ), $args );
	
}

add_action( 'init', 'casano_toolkit_custom_taxonomies', 0 );
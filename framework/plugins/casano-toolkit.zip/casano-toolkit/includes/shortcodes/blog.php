<?php

if ( ! class_exists( 'Casano_Shortcode_blog' ) ) {
	class Casano_Shortcode_blog extends Casano_Shortcode {
		/**
		 * Shortcode name.
		 *
		 * @var  string
		 */
		public $shortcode = 'blog';


		/**
		 * Default $atts .
		 *
		 * @var  array
		 */
		public $default_atts = array();


		public static function generate_css( $atts ) {
			// Extract shortcode parameters.
			extract( $atts );
			$css = '';

			return $css;
		}


		public function output_html( $atts, $content = null ) {
			$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'casano_blog', $atts ) : $atts;

			// Extract shortcode parameters.
			extract( $atts );

			$css_class   = array( 'casano-blog' );
			$css_class[] = $atts['style'];
			$css_class[] = $atts['el_class'];
			$css_class[] = $atts['blog_custom_id'];
			$css_class[] = $atts['animate_on_scroll'];
			if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
				$css_class[] = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );
			}
			$loop_posts = vc_build_loop_query( $atts['loop_query'] )[1];
			ob_start();
			?>
			<?php if ( $loop_posts->have_posts() ) : ?>
                <div class="<?php echo esc_attr( implode( ' ', $css_class ) ); ?>">
                    <?php if($atts['style'] == 'style-01'):?>
                        <?php
                        $owl_class[]  = 'owl-carousel' . $atts['nav_color'] . ' ' . $atts['dots_color'];
                        $owl_settings = $this->generate_carousel_data_attributes( '', $atts );
                        ?>
                        <div class="owl-carousel equal-container better-height <?php echo esc_attr( implode( ' ', $owl_class ) ); ?>" <?php echo force_balance_tags( $owl_settings ); ?>>
                            <?php while ( $loop_posts->have_posts() ) : $loop_posts->the_post() ?>
                                <?php
                                $classes = array( 'post-item' );
                                $classes[] = 'blog-grid';
                                ?>
                                <div <?php post_class( $classes ); ?>>
                                    <div class="post-thumb">
                                        <?php if ( has_post_thumbnail() ) {
                                            $image_thumb = casano_toolkit_resize_image( get_post_thumbnail_id(), null, 450, 397, true, false, false ); ?>
                                            <a href="<?php the_permalink(); ?>">
                                                <?php echo casano_toolkit_img_output( $image_thumb, 'attachment-post-thumbnail wp-post-image', get_the_title() ); ?>
                                            </a>
                                        <?php } ?>
                                    </div>
                                    <div class="post-content">
                                        <div class="post-info equal-elem">
                                            <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                            <div class="post-excerpt-content">
                                                <?php echo wp_trim_words( apply_filters( 'the_excerpt', get_the_excerpt() ), 14, esc_html__( '...', 'casano-toolkit' ) ); ?>
                                            </div>
                                        </div>
                                        <div class="post-foot">
                                            <a class="readmore-sc"
                                               href="<?php the_permalink(); ?>"><?php echo esc_html__( 'Read more', 'casano-toolkit' ); ?></a>
                                        </div>
                                        <?php if ( $atts['style'] == 'style-01' ): ?>
                                            <div class="post-meta">
                                                <?php
                                                casano_post_datebox();
                                                casano_post_comment();
                                                ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
				    <?php else : ?>
	                    <?php while ( $loop_posts->have_posts() ) : $loop_posts->the_post() ?>
                            <div <?php post_class('post-item'); ?>>
                                <div class="post-thumb">
				                    <?php if ( has_post_thumbnail() ) {
					                    $image_thumb = casano_toolkit_resize_image( get_post_thumbnail_id(), null, 79, 79, true, false, false ); ?>
                                        <a href="<?php the_permalink(); ?>">
						                    <?php echo casano_toolkit_img_output( $image_thumb, 'attachment-post-thumbnail wp-post-image', get_the_title() ); ?>
                                        </a>
				                    <?php } ?>
                                </div>
                                <div class="post-content">
                                    <div class="post-meta">
                                        <div class="date">
                                            <a href="<?php the_permalink(); ?>">
							                    <?php echo get_the_date('d.m.Y'); ?>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="post-info">
                                        <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    </div>
                                </div>
                            </div>
	                    <?php endwhile; ?>
                    <?php endif; ?>
                </div>
			<?php else : ?>
				<?php get_template_part( 'content', 'none' ); ?>
			<?php endif; ?>
			<?php
			$array_filter = array(
				'query' => $loop_posts,
			);
			wp_reset_postdata();
			$html = ob_get_clean();

			return apply_filters( 'Casano_Shortcode_blog', $html, $atts, $content, $array_filter );
		}
	}
}
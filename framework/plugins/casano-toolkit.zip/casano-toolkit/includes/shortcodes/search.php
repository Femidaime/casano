<?php

if (!class_exists('Casano_Shortcode_Search')) {
    class Casano_Shortcode_Search extends Casano_Shortcode
    {
        /**
         * Shortcode name.
         *
         * @var  string
         */
        public $shortcode = 'search';

        /**
         * Default $atts .
         *
         * @var  array
         */
        public $default_atts = array();


        public static function generate_css($atts)
        {
            // Extract shortcode parameters.
            extract($atts);
            $css = '';

            return $css;
        }


        public function output_html($atts, $content = null)
        {
            $atts = function_exists('vc_map_get_attributes') ? vc_map_get_attributes('casano_search', $atts) : $atts;

            // Extract shortcode parameters.
            extract($atts);

            $css_class = array('casano-search');
            $css_class[] = $atts['style'];
            $css_class[] = $atts['el_class'];
            $css_class[] = $atts['search_custom_id'];
            $css_class[] = $atts['animate_on_scroll'];
            if (function_exists('vc_shortcode_custom_css_class')) {
                $css_class[] = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class($atts['css'], ' '), '', $atts);
            }
            ob_start();
            ?>
            <div class="<?php echo esc_attr(implode(' ', $css_class)); ?>">
                <div class="sc-search-inner">
                    <?php if ($atts['title']): ?>
                        <h3 class="search-title"><?php echo esc_html($atts['title'])?></h3>
                    <?php endif; ?>
                    <?php
                    $post_type = class_exists('WooCommerce') ? 'product' : '';
                    $search_form_class = 'instant-search';
                    if ($post_type != 'product') {
                        $search_form_class .= ' instant-search-disabled';
                    }
                    ?>
                    <form autocomplete="off" method="get" class="search-form <?php echo esc_attr( $search_form_class ); ?>"
                          action="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <div class="search-fields">
                            <div class="search-input">
                                <span class="reset-instant-search-wrap"></span>
                                <input type="search" class="search-field"
                                       placeholder="<?php echo esc_attr( $atts['placeholder'] ); ?>" value="" name="s">
                                <?php if ( $post_type != '' ) { ?>
                                    <input type="hidden" name="post_type" value="<?php echo esc_attr( $post_type ); ?>">
                                <?php } ?>
                                <button type="submit" class="search-submit"><span class="flaticon-magnifying-glass"></span>
                                </button>
                                <input type="hidden" name="lang" value="en">
                                <div class="search-results-container search-results-croll scrollbar-macosx">
                                    <div class="search-results-container-inner">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php
            $html = ob_get_clean();

            return apply_filters('Casano_Shortcode_search', $html, $atts, $content);
        }
    }
}
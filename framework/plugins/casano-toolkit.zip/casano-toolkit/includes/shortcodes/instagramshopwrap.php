<?php

if ( ! class_exists( 'Casano_Shortcode_Instagramshopwrap' ) ) {
	class Casano_Shortcode_Instagramshopwrap extends Casano_Shortcode {
		/**
		 * Shortcode name.
		 *
		 * @var  string
		 */
		public $shortcode = 'instagramshopwrap';

		/**
		 * Default $atts .
		 *
		 * @var  array
		 */
		public $default_atts = array();


		public static function generate_css( $atts ) {
			extract( $atts );
			$css = '';

			return $css;
		}

		public function output_html( $atts, $content = null ) {
			$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'casano_instagramshopwrap', $atts ) : $atts;

			extract( $atts );
			$css_class   = array( 'casano-instagramshopwrap' );
			$css_class[] = $atts['el_class'];
			$css_class[] = $atts['iconimage'];
			$css_class[] = $atts['instagramshopwrap_custom_id'];
			$css_class[] = $atts['style'];
			if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
				$css_class[] = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );
			}
			$type_icon = isset( $atts['i_type'] ) ? $atts['i_type'] : '';
			if ( $type_icon == 'fontflaticon' ) {
				$class_icon = isset( $atts['icon_casanocustomfonts'] ) ? $atts['icon_casanocustomfonts'] : '';
			} else {
				$class_icon = isset( $atts['icon_fontawesome'] ) ? $atts['icon_fontawesome'] : '';
			}
			ob_start();
			?>
            <div class="<?php echo esc_attr( implode( ' ', $css_class ) ); ?>">
                <div class="title-insshop">
                    <div class="title-inner">
						<?php if ( $atts['iconimage'] == 'imagetype' && $atts['image'] ): ?>
                            <div class="image">
								<?php echo wp_get_attachment_image( $atts['image'], 'full' ); ?>
                            </div>
						<?php else: ?>
                            <div class="icon">
                                <span class="<?php echo esc_attr( $class_icon ); ?>"></span>
                            </div>
						<?php endif; ?>
                        <?php if ( $atts['title'] ): ?>
                            <h3 class="block-title"><?php echo esc_html( $atts['title'] ); ?></h3>
                        <?php endif; ?>
                    </div>
                </div>
				<?php echo wpb_js_remove_wpautop( $content ); ?>
            </div>
			<?php
			$html = ob_get_clean();

			return apply_filters( 'Casano_Shortcode_instagramshopwrap', $html, $atts, $content );
		}
	}
}